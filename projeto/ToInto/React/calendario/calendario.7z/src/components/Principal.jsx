import {Link} from "react-router-dom";
function Principal() {
  
    return (
        <div>
        </div>
    )
}
export default Principal;