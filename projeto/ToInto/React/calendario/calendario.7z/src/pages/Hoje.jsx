import Todolist from "../components/Todolist"

export default function Hoje(){
    return(
        <div>
            <Todolist/>
        </div>
    )
}