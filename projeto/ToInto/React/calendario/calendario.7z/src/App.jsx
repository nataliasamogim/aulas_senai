import Todolist from './components/Todolist';
import Calendario from './components/Calendario';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'
import Principal from './components/Principal';
import { BrowserRouter as Roteador, Routes, Route } from 'react-router-dom';
import Hoje from './pages/Hoje';



function App() {

  return (
    <div className="App" >
      <Roteador>
        <Calendario />
        <Principal />
        <Routes>
          <Route path="/Hoje" element={<Hoje />} />
          <Route path="/Semana" element={<Todolist />} />
          <Route path="/Importantes" element={<Todolist />} />
        </Routes>
      </Roteador>

    </div>
  )
}

export default App
