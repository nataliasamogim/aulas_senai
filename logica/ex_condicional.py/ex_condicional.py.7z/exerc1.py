a= float(input('Digite o primeiro número:'))
b= float(input('Digite o segundo número:'))
c= float(input('Digite o terceiro número:'))

soma=a+b

if(soma<c):
    print ('A soma é menor que c')

else:
    print ('A soma é  maior que c')