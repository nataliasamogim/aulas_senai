nome= str(input('Qual é o seu nome?:'))
sexo= str(input('Qual o seu sexo? (f) ou (m):'))
est_civil= str(input('Qual o seu estado civil? (solteira) ou (casada):'))

if(sexo=='f') and (est_civil=='casada'):
    (input('Quantos anos de casasa?:'))