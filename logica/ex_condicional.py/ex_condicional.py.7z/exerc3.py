n1=int(input('Digite um número:'))

modulo=n1%2

if (modulo==0):
    print('O número é par!')

else:
    print('O número é impar!')