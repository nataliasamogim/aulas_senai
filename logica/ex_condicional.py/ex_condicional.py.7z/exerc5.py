n= int(input('Digite um número:'))

modulo=n%2

if(modulo==0):
    soma= n+5
    print (soma)

else:
    soma= n+8
    print(soma)