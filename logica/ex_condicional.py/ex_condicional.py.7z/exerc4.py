a= int(input('Digite um número:'))
b= int(input('Digite outro número:'))

if (a==b):
    c=a+b
    print (c)

else:
    c=a*b
    print(c)